
#ifndef iniciar_h
#define iniciar_h

#include <stdio.h>
#include <iostream>
#include <string>
#include <stdlib.h>

bool iniciar (unsigned int i, uint8_t * data);

#endif /* iniciar_h */
