
#ifndef read_IPS_h
#define read_IPS_h

#include <stdio.h>
#include <iostream>
#include <fstream>

#define ARCHIVO "/Users/martumaspero/Desktop/directions.txt"

bool read_IPs(char* buffer, int n );
int getNumberOfLines (void);

#endif /* read_IPS_h */
